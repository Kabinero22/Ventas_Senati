
package com.app.productos.interfaces;

import com.app.productos.modelo.Empleado;

public interface IEmpleado {
    public Empleado getEmpleadoUserPass(String user,String pass);
}
