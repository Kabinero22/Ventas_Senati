var carouselItems = document.querySelector('.carousel-items');
var prevButton = document.querySelector('#btn-prev');
var nextButton = document.querySelector('#btn-next');

var itemWidth = 400; // Ancho de cada elemento del carrusel
var currentPosition = 0; // Posición actual del carrusel

prevButton.addEventListener('click', function() {
    currentPosition += itemWidth; // Aumenta la posición actual por el ancho de un elemento
    carouselItems.style.transform = `translateX(${currentPosition}px)`; // Desplazamiento hacia la izquierda
});

nextButton.addEventListener('click', function() {
    currentPosition -= itemWidth; // Disminuye la posición actual por el ancho de un elemento
    carouselItems.style.transform = `translateX(${currentPosition}px)`; // Desplazamiento hacia la derecha
});

